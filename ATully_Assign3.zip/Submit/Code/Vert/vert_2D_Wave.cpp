#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <mpi.h>
#include <chrono>

int main() {
    
    int M{2305};                                        // # grid intervals in space (square grid)
    double T{1};                                        // Total time to run for
    double dt{0.2/M};                                   // time step size
    int N = T/dt;                                       // # grid intervals in time
    int t1 = 0.333/dt, t2 = 0.666/dt, t3 = N;           // time steps to print results at for plotting purposes
    double dx{2.0/M};                                   // space step size
    double dx2{dx*dx};                                  // space step size squared
    double mu{dt*dt/dx2};                               // convenience variable
    int w{194};                                         // width of each interval
    double y_val{};                                        // variable to help with indexing

    int rank{}, size{};                                 // variables for rank and total number of processes

    MPI_Comm comm;

    comm = MPI_COMM_WORLD;
    MPI_Init(NULL,NULL);
    MPI_Comm_rank(comm, &rank);             // find the rank of the process
    MPI_Comm_size(comm, &size);             // find total number of processes

    int root_process{0};                    // designate root process

    auto start = MPI_Wtime();      // starts the timer 


    double*** U = new double**[3];
    double** E = new double*[3*(M+1)];
    double* F = new double[3*(M+1)*(w)];
    for (int i{0}; i<3; ++i) {
        for (int j{0}; j<=M; ++j) {
            E[(M+1)*i + j] = F + ((M+1)*i + j)*(w);
        }
        U[i] = E + (M+1)*i;
    }

    
    if (rank == root_process) {

        for (int i{1}; i<M; ++i) {                      // initial condition for left boundary interval
            
            for (int j{1}; j<w; ++j) {
                y_val = j * dx;
                U[0][i][j] = U[1][i][j] = exp(-40 * ( ( i*dx -1 - 0.4)*( i*dx -1 - 0.4) + (y_val-1)*(y_val-1) ) );
            }
        }
    }

    else if (rank == (size-1)) {

        for (int i{1}; i<M; ++i) {                      // initial condition for right boundary interval
            
            for (int j{0}; j<w-1; ++j) {
                y_val = (rank * (w-2) + j) * dx;
                U[0][i][j] = U[1][i][j] = exp(-40 * ( ( i*dx -1 - 0.4)*( i*dx -1 - 0.4) + (y_val-1)*(y_val-1) ) );
            }
        }
    }


    else {
        for (int i{1}; i<M; ++i) {                      // initial condition for each other interval
            
            for (int j{0}; j<w; ++j) {
                y_val = (rank * (w-2) + j) * dx;
                U[0][i][j] = U[1][i][j] = exp(-40 * ( ( i*dx -1 - 0.4)*( i*dx -1 - 0.4) + (y_val-1)*(y_val-1) ) );
            }
        }
    }


    if (rank == root_process) {                         // Boundary condition for left boundary interval
        for (int i{1}; i<M; ++i) {
            U[0][i][0] = U[1][i][0] = U[2][i][0] = 0;
        }
    }
    else if (rank == (size-1)) {                        // Boundary condition for right boundary interval
        for (int i{1}; i<M; ++i) {
            U[0][i][w-1] = U[1][i][w-1] = U[2][i][w-1] = 0;
        }
    }

    for (int j{0}; j<w; ++j) {                     // boundary conditions for upper and lower boundary for every interval 
        U[0][0][j] = U[0][M][j] = U[1][0][j] = U[1][M][j] = U[2][0][j] = U[2][M][j] = 0;
    }

    
    double** U_out = new double*[M+1];
    double* B = new double[(M+1)*(M+1)];
    for (int i{0}; i< (M+1); ++i) {
        U_out[i] = B + (M+1)*i;
    }
        
    for (int i{0}; i<=M; ++i) {
        MPI_Gather(&(U[0][i][0]), (w-2), MPI_DOUBLE, &(U_out[i][0]), (w-2), MPI_DOUBLE, 0, comm);         // Gather the initial condition to print to output 

        if (rank == (size-1)) {
            MPI_Send(&(U[0][i][w-2]), 2, MPI_DOUBLE, 0, 0, comm);
        }
        if (rank == root_process) {
            MPI_Recv(&(U_out[i][M-1]), 2, MPI_DOUBLE, (size-1), 0, comm, MPI_STATUS_IGNORE);
        }

    }

    auto initial_write_start = MPI_Wtime();

    if (rank == root_process) {
        std::ofstream out {"U_t0.csv"};              // open an output file
        out << std::fixed << std::setprecision(4);   // set the precision to 4 places
        for (int i{0}; i<=M; ++i) {
            for (int j{0}; j<=M; ++j) {
                out << U_out[i][j] << " ";           // write the initial solution to file
            }
            out << std::endl;
        }
        out.close();                                // close the output file
    }

    MPI_Barrier(comm);
    auto main_loop_start = MPI_Wtime();


    for (int t{1}; t<=N; ++t) {                 // Loop over time steps

        for (int i{1}; i<M; ++i) {                  // numerical scheme to predict U at next time step

            for (int j{1}; j<w-1; ++j) {
                U[2][i][j] = mu * ( U[1][i+1][j] + U[1][i-1][j] + U[1][i][j+1] + U[1][i][j-1] - 4 * U[1][i][j] ) + 2 * U[1][i][j] - U[0][i][j];
            }
        }


        for (int i{0}; i<=M; ++i) {
            // Halo swap - all swaps going right first
            if (rank == root_process) {                                             // Left interval halo-swap special case
                MPI_Send(&(U[2][i][w-2]), 1, MPI_DOUBLE, (rank+1), 1, comm);
            }
            else if (rank == (size-1)) {                                            // Right interval halo-swap special case
                MPI_Recv(&(U[2][i][0]), 1, MPI_DOUBLE, (rank-1), 1, comm, MPI_STATUS_IGNORE);
            }
            else {                                                                  // Halo-swapping
                MPI_Send(&(U[2][i][w-2]), 1, MPI_DOUBLE, (rank+1), 1, comm);
    
                MPI_Recv(&(U[2][i][0]), 1, MPI_DOUBLE, (rank-1), 1, comm, MPI_STATUS_IGNORE);
            }
        }
        
        for (int i{0}; i<=M; ++i) {
            // Now all swaps going left
            if (rank == root_process) {                                             // Left interval halo-swap special case
                MPI_Recv(&(U[2][i][w-1]), 1, MPI_DOUBLE, (rank+1), 0, comm, MPI_STATUS_IGNORE);
            }
    
            else if (rank == (size-1)) {                                            // Right interval halo-swap special case
                MPI_Send(&(U[2][i][1]), 1, MPI_DOUBLE, (rank-1), 0, comm);
            }
    
            else {                                                                  // Halo-swapping
                MPI_Send(&(U[2][i][1]), 1, MPI_DOUBLE, (rank-1), 0, comm);
    
                MPI_Recv(&(U[2][i][w-1]), 1, MPI_DOUBLE, (rank+1), 0, comm, MPI_STATUS_IGNORE);
            }
        }


        for (int i{0}; i<=M; ++i) {          // Update old time steps to new steps
           for (int j{0}; j<w; ++j ) {
               U[0][i][j] = U[1][i][j];
               U[1][i][j] = U[2][i][j];
           }
        }


        if (t==t1 || t==t2 || t==t3) {          // Print to file at designated print times specified at start of code
            MPI_Barrier(comm);          // ensure all process reach this point together


            for (int i{0}; i<=M; ++i) {
                MPI_Gather(&(U[2][i][0]), (w-2), MPI_DOUBLE, &(U_out[i][0]), (w-2), MPI_DOUBLE, 0, comm);         // Gather the initial condition to print to output 

                if (rank == (size-1)) {
                    MPI_Send(&(U[2][i][w-2]), 2, MPI_DOUBLE, 0, 0, comm);
                }
                if (rank == root_process) {
                    MPI_Recv(&(U_out[i][M-1]), 2, MPI_DOUBLE, (size-1), 0, comm, MPI_STATUS_IGNORE);
                }

            }   


            if (t==t1){
                auto write_start1 = MPI_Wtime();
            }
            if (t==t2){
                auto write_start2 = MPI_Wtime();
            }
            if (t==t3){
                auto write_start3 = MPI_Wtime();
            }


            if (rank == root_process) {

                std::stringstream ss;
                ss << std::fixed << std::setprecision(2) << t*dt;
                std::string time = ss.str();

                std::ofstream out {"U_t"+ss.str()+".csv"};
                out << std::fixed << std::setprecision(4);
                for (int i{0}; i<=M; ++i) {
                    for (int j{0}; j<=M; ++j) {
                        out << U_out[i][j] <<  " ";
                    }
                    out << std::endl;
                }
                out.close();
                
                if (t==t1){
                    auto write_end1 = MPI_Wtime();
                }
                if (t==t2){
                    auto write_end2 = MPI_Wtime();
                }
                if (t==t3){
                    auto write_end3 = MPI_Wtime();
                }
            
            }
            
        }

        std::cout <<  "Iteration " << t << " completed." << std::endl;
    }

    auto main_loop_end = MPI_Wtime();

    MPI_Barrier(comm);
    delete U;
    delete E;
    delete F;
    delete U_out;
    delete B;

    auto time_taken = main_loop_end - start;
    std::cout<<"Total Computation time: "<<time_taken<<std::endl;



/*    if (rank == root_process) {
        auto end = std::chrono::steady_clock::now();
        auto time_taken = end - start;                      // calculate the final time for computation and print time taken
        std::cout << "Computation time taken: " << std::chrono::duration <double, std::milli> (time_taken).count() << " ms" << std::endl;
    }
*/
    MPI_Finalize();

    return 0;
}

