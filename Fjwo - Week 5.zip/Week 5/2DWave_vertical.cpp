#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <mpi.h>

using namespace std;

int main(int argc, char* argv[]){

int rank, size, ierr;
int M = 8193;  // M length intervals.
int nproc = 32;
int J = ((M-1)/nproc)+2;
double t_start, t_end, run_time;
double sendU, sendL;
double T = 1;  // final time.
double dt = 0.2/M;
int N = T/dt;
int t1=0.333/dt, t2=0.666/dt, t3=N; // points at which we want to print our results.
double dy = 2./M;
double dy2 = dy*dy;
double dtdy2 = dt*dt/dy2;

MPI_Status status;
MPI_Comm comm;
comm = MPI_COMM_WORLD;
MPI_Init(NULL,NULL);
MPI_Comm_rank(comm, &rank);
MPI_Comm_size(comm, &size);

t_start = MPI_Wtime();

// now lets create our annoyingly large array...
// double U[3][M+1][M+1];  // 3D array, the first dimension for three different times.
								  // this does not work for large M, however... test it!

//if (rank == 0){
  // dynamically allocate enough memory to create the array.
  double*** U = new double** [3]; // this creates an array of size 3 which is ready do hold 2D arrays in each entry.
  for (int i = 0; i < 3; ++i) {   // this loop puts an array of size M+1 on each of the three entries.
    U[i] = new double*[M+1];		  // we get a 2D array.
    for (int j = 0; j < M+1; ++j){ // put another array on each entry of the 2D array to get a 3D array.
      U[i][j] = new double[M+1];
    }
  }
  // apart from array deletion at the end, everything else stays as usual..

  // initialize numerical array with given conditions.
  for (int i=1; i<M; ++i){
    for (int j=1; j<M; ++j){
      U[0][i][j] = U[1][i][j] = exp( -40 * ( (i*dy-1-0.4)*(i*dy-1-0.4) + (j*dy-1)*(j*dy-1) ) );
    }
  }
  for (int i=0; i<=M; ++i){ 
    U[0][0][i] = U[0][M][i] = U[1][0][i] = U[1][M][i] = U[2][0][i] = U[2][M][i] = 0;
    U[0][i][0] = U[0][i][M] = U[1][i][0] = U[1][i][M] = U[2][i][0] = U[2][i][M] = 0; 	
  }

  // print initial U values to file, row by row.
  ofstream out {"Up_t0.csv"};
  out<<fixed<<setprecision(4);
  for(int i=0; i<=M; ++i){
    for(int j=0; j<=M; ++j){					
      out<<U[0][i][j]<<" ";
    }
    out<<endl;
  }	
  out.close();
//}
//MPI_Bcast(U, (3*M*M), MPI_FLOAT, 0, comm);

//if (rank==0) {
  //cout<<"J = "<<J<<", was = "<<((M-2)/nproc)+2<<endl;
//}

// use numerical scheme to obtain the future values of U.
for (int t=1; t<=N; ++t){
	
	for (int i=1; i<J-1; ++i){
		for (int j=1; j<M; ++j){		
			U[2][i+((J-2)*rank)][j] = 2*U[1][i+((J-2)*rank)][j] - U[0][i+((J-2)*rank)][j]	 
						 	 + dtdy2*( U[1][i+1+((J-2)*rank)][j] + U[1][i-1+((J-2)*rank)][j] + U[1][i+((J-2)*rank)][j+1] + U[1][i+((J-2)*rank)][j-1] - 4*U[1][i+((J-2)*rank)][j] ); 	
		}		
	}
	

        for (int j=1; j<M; ++j) {
          if (rank > 0) {
            sendL = U[2][1+((J-2)*rank)][j];
            MPI_Send(&sendL, 1, MPI_DOUBLE, rank-1, 1, comm);
          }
          if (rank < nproc-1) {
            MPI_Recv(&sendL, 1, MPI_DOUBLE, rank+1, 1, comm, &status);
            U[2][1+((J-2)*(rank+1))][j] = sendL;
            sendU = U[2][(J-2)*(rank+1)][j];
            MPI_Send(&sendU, 1, MPI_DOUBLE, rank+1, 0, comm);
          }
          if (rank > 0) {
            MPI_Recv(&sendU, 1, MPI_DOUBLE, rank-1, 0, comm, &status);
            U[2][((J-2)*rank)][j] = sendU;
          }

          //MPI_Barrier(comm);
        }

	// update the previous times.
	for (int i=0; i<=J-1; ++i){
		for (int j=1; j<M; ++j){		
			U[0][i+((J-2)*rank)][j] = U[1][i+((J-2)*rank)][j];
			U[1][i+((J-2)*rank)][j] = U[2][i+((J-2)*rank)][j];
			}		
	}


	
   // print out files for fixed times	
//	if(t==t1 || t==t2 || t==t3){	
//		stringstream ss;
//		ss << fixed << setprecision(2) << t*dt; // this ensures that the double value gets converted
//		string time = ss.str();						 // to string with only 2 trailing digits.
//		
//		ofstream out {"Up_t"+ss.str()+".csv"};
//		out<<fixed<<setprecision(4);			
//                        for(int k=0; k<nproc; ++k) {
//                          if (rank == 0) {
//                            for (int j=0; j<=M; ++j) {
//                              out<<U[2][0][j]<<" ";
//                            }
//                          }
//                          for(int i=1; i<J-1; ++i) {
//                            if (rank == k) {
//                              for(int j=0; j<=M; ++j) {		
//					out<<U[2][i+((J-2)*rank)][j]<<" ";
//			      }
//                          }
//                          if (rank == nproc-1) {
//                            for(int j=0; j<=M; ++j){
//                              out<<U[2][M][j]<<" ";
//                            }
//                          }
//                          out<<endl;
//                          }
//			}
//		out.close();
//	}		
      if (rank==0) {
        cout<<"iteration "<<t<<" done"<<endl;	
      }
      if (rank==0) {
        cout<<U[2][4][4]<<endl;
      }
}

MPI_Barrier(comm);
if (rank==0){
  cout<<"----"<<endl;
  t_end = MPI_Wtime();
  run_time = t_end - t_start;
  cout<<"Runtime = "<<run_time<<endl;
}

// now we need to delete the array.
for (int i = 0; i < 3; i++)
{
    for (int j = 0; j < M+1; j++){
        delete[] U[i][j];
	 }    
    delete[] U[i];
}

delete[] U;


return 0;

MPI_Finalize();

}
